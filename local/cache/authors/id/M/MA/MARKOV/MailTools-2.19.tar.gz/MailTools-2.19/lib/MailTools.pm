# Copyrights 1995-2017 by [Mark Overmeer <perl@overmeer.net>].
#  For other contributors see ChangeLog.
# See the manual pages for details on the licensing terms.
# Pod stripped from pm file by OODoc 2.02.
package MailTools;
use vars '$VERSION';
$VERSION = '2.19';



1;
